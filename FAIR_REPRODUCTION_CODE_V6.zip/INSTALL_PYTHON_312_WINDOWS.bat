@echo off
setlocal EnableExtensions
echo ================================================================
echo Install Python 3.12 for FaIR reproduction
 echo ================================================================
echo This will invoke Windows Package Manager to install Python 3.12.
echo It does not uninstall, downgrade, or replace other Python versions.
echo This installation requires network access and your consent.
echo.
where winget >nul 2>&1
if errorlevel 1 goto :no_winget
choice /C YN /N /M "Install Python 3.12 now? [Y/N]: "
if errorlevel 2 goto :cancel
winget install --id Python.Python.3.12 --exact --source winget --accept-package-agreements --accept-source-agreements
if errorlevel 1 goto :failed
echo.
echo Installation command completed. Close and reopen Command Prompt.
echo Then double-click RUN_WINDOWS.bat in this V4 package.
pause
exit /b 0
:no_winget
echo ERROR: winget is not available on this Windows installation.
echo Download Python 3.12 x64 from https://www.python.org/downloads/
echo Enable the Python launcher when installing.
pause
exit /b 1
:cancel
echo Installation cancelled. No changes made by this script.
pause
exit /b 0
:failed
echo Installation did not finish successfully.
echo Visit https://www.python.org/downloads/ for a manual Python 3.12 installer.
pause
exit /b 1
