@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ================================================================
echo Python installation diagnostic - does NOT modify your system
echo ================================================================
echo Python launcher installations:
where py >nul 2>&1
if errorlevel 1 (echo py launcher: not found) else (py -0p)
echo.
echo Default Python:
where python >nul 2>&1
if errorlevel 1 (echo python command: not found) else (python --version)
echo.
echo Python 3.12 x64 check:
where py >nul 2>&1
if not errorlevel 1 py -3.12 -c "import sys,struct;print(sys.executable);print(sys.version);print('64-bit:',struct.calcsize('P')==8)"
echo.
echo Git:
where git >nul 2>&1
if errorlevel 1 (echo git command: not found) else (git --version)
echo.
echo Existing dedicated environment:
if exist .venv_py312\Scripts\python.exe (
  .venv_py312\Scripts\python.exe --version
) else (
  echo No .venv_py312 yet; it is created on first run.
)
pause
