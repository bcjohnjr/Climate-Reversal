@echo off
cd /d "%~dp0"
call "%~dp0RUN_WINDOWS.bat" preflight
exit /b %errorlevel%
