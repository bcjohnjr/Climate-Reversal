@echo off
cd /d "%~dp0"
call "%~dp0RUN_WINDOWS.bat" full
exit /b %errorlevel%
