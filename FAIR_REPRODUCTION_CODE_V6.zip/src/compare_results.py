#!/usr/bin/env python3
"""Strict scientific and completeness audit of rebuilt FaIR sensitivity runs.

The legacy comparator skipped missing cases. This version refuses to call any
scope successful unless every expected case has complete, finite outputs,
841 unique member IDs, genuine model metadata and all applicable manuscript
numerical comparisons. It NEVER alters published reference values.
"""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
import numpy as np,pandas as pd

YEARS=[2100,2150,2183]
HEADERS=['group','case','metric','actual','published','abs_error','tolerance','pass']

def number(x):return float(str(x).replace(',','').replace('−','-').replace('–','-'))
def close(a,b,tol=.02):return np.isfinite(a) and np.isfinite(b) and abs(a-b)<=tol

def caseid_size(total,rate,phase):return f'size_{total:.2f}_rate_{rate:.0f}_{phase}'
def caseid_bg(bg,total,rate,phase):
 return f'background_{bg}_size_{total:.2f}_rate_{rate:.0f}_{phase}' if bg!='canonical' else caseid_size(total,rate,phase)

def inspect_case(path:Path,name:str):
 required=[path/'validation.json',path/'fair_summary_endpoints.csv',path/'fair_median_timeseries.csv']
 required +=[path/f'fair_member_metrics_end_{end}.csv' for end in YEARS]
 missing=[x.name for x in required if not x.is_file()]
 if missing:raise ValueError('Missing outputs: '+', '.join(missing))
 val=json.loads((path/'validation.json').read_text(encoding='utf-8'))
 for key,want in [('status','PASS'),('configurations',841),('model_timebound',2184),
   ('emissions_last_year',2183),('fair_source_commit','ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79'),
   ('v62_runner_commit','89a0f4ab18df25db3a05d4e39c6db06405456505')]:
  if val.get(key)!=want:raise ValueError(f'{key}={val.get(key)} instead of {want}')
 if val.get('case_file')!=name+'.csv':raise ValueError('Case ID mismatch')
 tol=val.get('forcing_tolerance')
 if tol not in (1e-4,1e-7):raise ValueError('Unexpected forcing tolerance')
 for key in ('max_off_residual','max_on_residual'):
  if not close(float(val[key]),0,tol):raise ValueError('Forcing residual > tolerance: '+key)
 if name.startswith('background_') and val.get('background_scenario') not in {'low','medium','high'}:
  raise ValueError('Background source unverified')
 if name.startswith('leak_') and not val.get('off_stored_reversal_zero'):
  raise ValueError('Leakage OFF branch incorrectly includes programme reversal')
 su=pd.read_csv(path/'fair_summary_endpoints.csv')
 if set(su.endpoint_year)!=set(YEARS) or len(su)!=3:
  raise ValueError('Missing or duplicate 2100, 2150, 2183 endpoints')
 if not np.array_equal(su.sort_values('endpoint_year').terminal_bound.to_numpy(),np.array(YEARS)+1):
  raise ValueError('Wrong end-of-emissions evaluation bound')
 nums=su.select_dtypes(include='number').to_numpy(dtype=float)
 if not np.isfinite(nums).all():raise ValueError('Nonfinite summary metric')
 ts=pd.read_csv(path/'fair_median_timeseries.csv')
 if len(ts)!=159 or not np.array_equal(ts.year_bound.to_numpy(),np.arange(2026,2185)):
  raise ValueError('Missing annual median timebound 2026..2184')
 if not np.isfinite(ts.select_dtypes(include='number').to_numpy(dtype=float)).all():
  raise ValueError('Nonfinite time series')
 members={};member_ids=None
 for end in YEARS:
  mem=pd.read_csv(path/f'fair_member_metrics_end_{end}.csv',dtype={'member_id':str})
  if len(mem)!=841 or mem.member_id.nunique()!=841:
   raise ValueError(f'Expected 841 unique member IDs for {end}')
  if not set(mem.terminal_bound)=={end+1}:raise ValueError('Member metric bound mismatch')
  if member_ids is None:member_ids=set(mem.member_id)
  elif set(mem.member_id)!=member_ids:raise ValueError('Member identifiers change across endpoints')
  if not np.isfinite(mem.drop(columns=['member_id']).to_numpy(dtype=float)).all():
   raise ValueError('Nonfinite paired member metric')
  members[end]=mem.set_index('member_id').sort_index()
 return su.set_index('endpoint_year'),members,val

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--results',default='results');ap.add_argument('--references',default='references')
 ap.add_argument('--out',default='reports');ap.add_argument('--expected-cases',required=True,
  help='JSON object with scope and explicit case_ids; no silent acceptance of partial matrices')
 args=ap.parse_args();root=Path(args.results);refs=Path(args.references)
 out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
 ex=json.loads(Path(args.expected_cases).read_text(encoding='utf-8'))
 scope=ex.get('scope');names=ex.get('case_ids')
 if scope not in ('smoke','core','background','full') or not isinstance(names,list) or not names or len(names)!=len(set(names)):
  raise ValueError('Expected-cases manifest missing, empty or invalid')
 if scope=='smoke' and names!=['size_100.00_rate_2_early','size_100.00_rate_2_late']:
  raise ValueError('Smoke scope must contain exactly canonical 100/2 pair')
 expected_n={'smoke':2,'core':44,'background':12,'full':56}[scope]
 if len(names)!=expected_n:raise ValueError(f'Scope {scope} must enumerate {expected_n} cases; got {len(names)}')
 missing=[];invalid={};results={}
 for name in names:
  try:results[name]=inspect_case(root/name,name)
  except (ValueError,FileNotFoundError,KeyError,TypeError,IndexError) as e:
   if not (root/name/'validation.json').exists():missing.append(name)
   else:invalid[name]=str(e)
 comparisons=[]
 def add(group,case,metric,actual,published,tol=.02):
  actual=float(actual);published=float(published)
  comparisons.append({'group':group,'case':case,'metric':metric,'actual':actual,
   'published':published,'abs_error':abs(actual-published),
   'tolerance':tol,'pass':bool(close(actual,published,tol))})
 def pair(early,late):
  if early not in results or late not in results:return None
  es,em,_=results[early];ls,lm,_=results[late]
  for end in YEARS:
   if not em[end].index.equals(lm[end].index):
    raise ValueError(f'Member IDs not paired: {early} / {late}')
  return es,em,ls,lm
 def joint(em,lm):
  a=em[2183];b=lm[2183]
  dterm=b.terminal_delta_co2_ppm-a.terminal_delta_co2_ppm
  dforcing=a.integrated_co2_forcing_benefit_wm2_year-b.integrated_co2_forcing_benefit_wm2_year
  return int(((dterm>0)&(dforcing>0)).sum()),float(dterm.min())
 # S3 size/rate matrix
 if scope in ('smoke','core','full'):
  table=pd.read_csv(refs/'published_Table_S3.csv')
  for row in table.itertuples(index=False):
   total=number(row[0]);rate=number(row[1]);name=f'size_{total:.2f}_rate_{rate:.0f}_'
   pairdata=pair(name+'early',name+'late')
   if pairdata is None:continue
   es,em,ls,lm=pairdata;count,low=joint(em,lm)
   add('Table S3',name,'early integrated forcing advantage Wm-2yr',es.loc[2183,'integrated_forcing_central_wm2yr']-ls.loc[2183,'integrated_forcing_central_wm2yr'],number(row[2]))
   add('Table S3',name,'late terminal atmospheric advantage ppm',ls.loc[2183,'terminal_delta_co2_central_ppm']-es.loc[2183,'terminal_delta_co2_central_ppm'],number(row[3]))
   add('Table S3',name,'early integrated warming advantage C yr',es.loc[2183,'integrated_warming_central_cyr']-ls.loc[2183,'integrated_warming_central_cyr'],number(row[5]))
   add('Table S3',name,'minimum member late terminal advantage ppm',low,number(row[6]))
   add('Table S3',name,'members satisfying both rankings',count,841,0)
 # S5 leakage (only core/full)
 if scope in ('core','full'):
  for row in pd.read_csv(refs/'published_Table_S5.csv').itertuples(index=False):
   f=number(row[0])/100; tau=0 if str(row[1]).strip() in ('—','-','') else int(number(row[1]));stem=f'leak_{f:.2f}_tau_{tau}_'
   p=pair(stem+'early',stem+'late')
   if p is None:continue
   es,em,ls,lm=p;count,_=joint(em,lm)
   add('Table S5',stem,'early integrated forcing advantage Wm-2yr',es.loc[2183,'integrated_forcing_central_wm2yr']-ls.loc[2183,'integrated_forcing_central_wm2yr'],number(row[2]))
   add('Table S5',stem,'late terminal atmospheric advantage ppm',ls.loc[2183,'terminal_delta_co2_central_ppm']-es.loc[2183,'terminal_delta_co2_central_ppm'],number(row[3]))
   add('Table S5',stem,'early integrated warming advantage C yr',es.loc[2183,'integrated_warming_central_cyr']-ls.loc[2183,'integrated_warming_central_cyr'],number(row[4]))
   add('Table S5',stem,'members satisfying both rankings',count,841,0)
 # S6 front/back pair
 if scope in ('core','full'):
  p=pair('year2100_front','year2100_back')
  if p:
   es,em,ls,lm=p
   for row in pd.read_csv(refs/'published_Table_S6.csv').itertuples(index=False):
    end=int(re.search(r'\d{4}',str(row[0])).group())
    add('Table S6','400GtCO2',str(end)+' back minus front terminal CO2 ppm',ls.loc[end,'terminal_delta_co2_central_ppm']-es.loc[end,'terminal_delta_co2_central_ppm'],number(row[1]))
    add('Table S6','400GtCO2',str(end)+' front minus back forcing Wm-2yr',es.loc[end,'integrated_forcing_central_wm2yr']-ls.loc[end,'integrated_forcing_central_wm2yr'],number(row[3]))
    add('Table S6','400GtCO2',str(end)+' front minus back warming Cyr',es.loc[end,'integrated_warming_central_cyr']-ls.loc[end,'integrated_warming_central_cyr'],number(row[4]))
 # S4: 2 canonical and 6 official alternative background rows.
 if scope in ('background','full','core'):
  for row in pd.read_csv(refs/'published_Table_S4.csv').itertuples(index=False):
   name=str(row[0]).strip().lower()
   if scope=='background' and name=='canonical':continue
   if scope=='core' and name!='canonical':continue
   amount=re.search(r'[\d,.]+',str(row[2])).group();rate=re.search(r'\bat\s*(\d+)',str(row[2])).group(1)
   total=number(amount);rate=float(rate)
   early=caseid_bg(name,total,rate,'early');late=caseid_bg(name,total,rate,'late')
   p=pair(early,late)
   if not p:continue
   es,em,ls,lm=p;count,minterm=joint(em,lm)
   tag=f'{name}-{total:.2f}-r{rate:.0f}'
   # Manuscript S4 'OFF CO2 in 2100' uses FaIR timebound 2100,
   # whereas endpoint_year 2100 in the summary is evaluated at bound 2101.
   # Use the original saved annual time series explicitly to avoid this
   # one-year systematic miscomparison (low/medium/high are most sensitive).
   annual = pd.read_csv(root/early/'fair_median_timeseries.csv')
   source_row = annual.loc[annual.year_bound==2100,'co2_off_p50_ppm']
   if len(source_row)!=1:raise ValueError('Timebound 2100 OFF concentration unavailable: '+early)
   add('Table S4',tag,'OFF CO2 at timebound 2100 ppm',float(source_row.iloc[0]),number(row[1]),.51)
   add('Table S4',tag,'early integrated forcing advantage Wm-2yr',es.loc[2183,'integrated_forcing_central_wm2yr']-ls.loc[2183,'integrated_forcing_central_wm2yr'],number(row[3]))
   add('Table S4',tag,'late terminal atmospheric advantage ppm',ls.loc[2183,'terminal_delta_co2_central_ppm']-es.loc[2183,'terminal_delta_co2_central_ppm'],number(row[4]))
   add('Table S4',tag,'late terminal warming advantage C',ls.loc[2183,'terminal_avoided_warming_central_c']-es.loc[2183,'terminal_avoided_warming_central_c'],number(row[5]),.002)
   add('Table S4',tag,'minimum member late terminal advantage ppm',minterm,number(row[6]))
   add('Table S4',tag,'members satisfying both rankings',count,841,0)
 df=pd.DataFrame(comparisons,columns=HEADERS)
 df.to_csv(out/'comparison.csv',index=False)
 fails=int((~df['pass']).sum()) if len(df) else 0
 success=not missing and not invalid and fails==0 and bool(comparisons)
 status=({'smoke':'SMOKE_ONLY_VERIFIED_NOT_FULL_REPRODUCTION',
   'core':'CORE_44_PASSED_NOT_BACKGROUND','background':'BACKGROUND_12_PASSED_NOT_CORE',
   'full':'FULL_56_NUMERICALLY_REPRODUCED'}[scope] if success else 'INCOMPLETE_OR_NUMERIC_MISMATCH')
 summary={'status':status,'scope':scope,'expected_cases':len(names),'valid_cases':len(results),
  'missing_cases':missing,'invalid_cases':invalid,'published_comparisons':len(comparisons),
  'comparisons_passed':len(comparisons)-fails,'comparisons_failed':fails,
  'scientific_warning':'Source-target agreement is not proof of the independence or correctness of the published model assumptions; paper and exact figure scripts still require review.'}
 (out/'status.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(summary,indent=2))
 if not success:raise SystemExit(1)
if __name__=='__main__':main()
