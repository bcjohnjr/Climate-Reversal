#!/usr/bin/env python3
"""Pinned-source local orchestrator, offline preflight and full 56-case FaIR matrix.

Commands run in the foreground. A case is PASS only if a real FaIR output
with 841 distinct member IDs, a 2184 evaluation bound, and valid forcing fit
is written; input checks and mock tests are reported separately.
"""
from __future__ import annotations
import argparse,json,os,subprocess,sys
from pathlib import Path
import pandas as pd
ROOT=Path(__file__).resolve().parents[1]
SOURCES={
 'v62':('https://github.com/bcjohnjr/Planetary-Restoration-Version-62.2.git','89a0f4ab18df25db3a05d4e39c6db06405456505'),
 'fair':('https://github.com/OMS-NetZero/FAIR.git','ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79')}
EM_REL='examples/data/calibrated_constrained_ensemble/extensions_1750-2500.csv'

def run(args,cwd=None,env=None):
 print('+',' '.join(str(s) for s in args),flush=True)
 subprocess.run([str(s) for s in args],check=True,cwd=cwd,env=env)

def source(name):
 url,sha=SOURCES[name];path=ROOT/'pinned_source'/name
 if not path.exists():
  path.parent.mkdir(exist_ok=True)
  run(['git','clone',url,path])
 try:actual=subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()
 except subprocess.CalledProcessError:raise RuntimeError('Missing/invalid pinned git source: '+str(path))
 if actual!=sha:run(['git','-C',str(path),'checkout','--detach',sha])
 if subprocess.check_output(['git','-C',str(path),'rev-parse','HEAD'],text=True).strip()!=sha:
  raise RuntimeError('Pinned source commit mismatch: '+name)
 dirty=subprocess.check_output(['git','-C',str(path),'status','--porcelain','--untracked-files=no'],text=True).strip()
 if dirty:raise RuntimeError('Pinned source has modified tracked files: '+name+' '+dirty)
 return path

def prepare_inputs(official_emissions=None):
 run([sys.executable,str(ROOT/'src/build_inputs.py'),'--baseline',str(ROOT/'references/v67_fixed_early.csv'),'--out',str(ROOT/'inputs')],cwd=ROOT)
 run([sys.executable,str(ROOT/'src/audit_archived_v67.py')],cwd=ROOT)
 run([sys.executable,str(ROOT/'src/test_preflight.py')],cwd=ROOT)
 if official_emissions:
  run([sys.executable,str(ROOT/'src/build_background.py'),'--emissions',str(official_emissions),
       '--baseline',str(ROOT/'references/v67_fixed_early.csv'),'--out',str(ROOT/'inputs')],cwd=ROOT)

def select(manifest,scope,one=None):
 if one:
  if one not in set(manifest.case_id):raise ValueError('Unknown case: '+one)
  return [one]
 if scope=='smoke':return ['size_100.00_rate_2_early','size_100.00_rate_2_late']
 if scope=='core':return list(manifest.loc[manifest.group!='background','case_id'])
 if scope=='background':return list(manifest.loc[manifest.group=='background','case_id'])
 if scope=='full':return list(manifest.case_id)
 raise ValueError('Bad scope')

def main():
 ap=argparse.ArgumentParser()
 ap.add_argument('--scope',choices=['preflight','smoke','core','background','full'],default='smoke')
 ap.add_argument('--case-id',default=None)
 ap.add_argument('--skip-existing',action='store_true')
 ap.add_argument('--compare',action='store_true',help='Do strict completeness check on all expected cases')
 a=ap.parse_args()
 if a.scope=='preflight':
  prepare_inputs();print('OFFLINE PREFLIGHT PASS — no new FaIR simulation executed');return
 fair=source('fair');v62=source('v62')
 src=fair/EM_REL
 if not src.exists():raise RuntimeError('Official FaIR emissions CSV missing: '+str(src))
 runner=v62/'run_fair_matched_forcing_v62.py'
 if not runner.exists():raise RuntimeError('Pinned V62 matched-forcing source absent')
 if not (fair/'examples/data/calibrated_constrained_ensemble/calibrated_constrained_parameters_calibration1.4.1.csv').exists():
  raise RuntimeError('Pinned 841-member fair-calibrate 1.4.1 data missing')
 prepare_inputs(src)
 manifest=pd.read_csv(ROOT/'inputs/manifest.csv').fillna('')
 if len(manifest)!=56:raise RuntimeError('Expected all 56 case inputs')
 ids=select(manifest,a.scope,a.case_id)
 env=os.environ.copy();env.update(FAIR_SOURCE_DIR=str(fair),PYTHONUNBUFFERED='1')
 for caseid in ids:
  row=manifest.set_index('case_id').loc[caseid]
  resultdir=ROOT/'results'/caseid
  if a.skip_existing and (resultdir/'validation.json').exists():
   validation=json.loads((resultdir/'validation.json').read_text())
   required=[resultdir/'fair_summary_endpoints.csv',resultdir/'fair_median_timeseries.csv']
   required += [resultdir/f'fair_member_metrics_end_{y}.csv' for y in [2100,2150,2183]]
   if (validation.get('status')=='PASS' and validation.get('model_timebound')==2184
       and validation.get('configurations')==841 and all(x.is_file() for x in required)):
    print('SKIP verified-output presence:',caseid);continue
  cmd=[sys.executable,str(ROOT/'src/run_fair_case.py'),
       '--case-file',str(ROOT/'inputs'/str(row['file'])),
       '--reference',str(ROOT/'references/v67_fixed_early.csv'),
       '--runner',str(runner),'--out',str(resultdir)]
  if str(row['protocol'])=='leakage':cmd.append('--off-zero')
  if str(row['protocol'])=='background':
   cmd+=['--background',str(row['background_scenario']),'--emissions',str(src)]
  run(cmd,cwd=ROOT,env=env)
 print('EXECUTED:',len(ids),'FaIR cases (check reports for numerical agreement)')
 if a.compare or not a.case_id:
  root=ROOT/'reports';root.mkdir(exist_ok=True)
  (root/'expected_cases.json').write_text(json.dumps({'scope':a.scope,'case_ids':ids},indent=2)+'\n')
  run([sys.executable,str(ROOT/'src/compare_results.py'),
   '--results',str(ROOT/'results'),'--references',str(ROOT/'references'),
   '--out',str(root),'--expected-cases',str(root/'expected_cases.json')],cwd=ROOT)
if __name__=='__main__':main()
