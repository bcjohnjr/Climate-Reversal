#!/usr/bin/env python3
"""Reconstruct disclosed scenario INPUTS, not FaIR model outputs.

Sources: V67 fixed__early artifact; submitted supplementary methods. The
reconstruction does not claim to recover the author's original input files.
"""
from __future__ import annotations
import argparse, csv, math, json
from pathlib import Path
import numpy as np
import pandas as pd

TOTAL = 2013.8807318595145
COLS=['year','gross_co2_gtco2','permafrost_co2_gtco2','stored_carbon_reversal_gtco2','cdr_gtco2','net_co2_gtco2']

def check(df):
    assert list(df.columns)==COLS, df.columns
    assert np.array_equal(df.year.to_numpy(),np.arange(2026,2184))
    z=df.gross_co2_gtco2+df.permafrost_co2_gtco2+df.stored_carbon_reversal_gtco2-df.cdr_gtco2
    assert float(np.max(np.abs(z-df.net_co2_gtco2)))<1e-9
    assert np.isfinite(df[COLS].to_numpy(dtype=float)).all()
    assert (df.cdr_gtco2 >= -1e-12).all()

def pulse(years,total,rate,late):
    full=int(math.floor(total/rate+1e-11)); remainder=total-full*rate
    if abs(remainder)<1e-9: remainder=0.
    slots=full+int(remainder>0)
    eligible=np.where(years>=2027)[0]
    if slots>len(eligible):raise ValueError('Schedule cannot fit eligibility window')
    chosen=eligible[-slots:] if late else eligible[:slots]
    arr=np.zeros(len(years),float)
    if late:
        if remainder: arr[chosen[0]]=remainder;chosen=chosen[1:]
        arr[chosen]=rate
    else:
        arr[chosen[:full]]=rate
        if remainder:arr[chosen[full]]=remainder
    assert abs(arr.sum()-total)<1e-7
    assert max(arr)<=rate+1e-8
    return arr

def scenario(base,cdr,stored=None,gross=None):
    x=base.copy()
    x['cdr_gtco2']=cdr
    if stored is not None:x['stored_carbon_reversal_gtco2']=stored
    if gross is not None:x['gross_co2_gtco2']=gross
    x['net_co2_gtco2']=x.gross_co2_gtco2+x.permafrost_co2_gtco2+x.stored_carbon_reversal_gtco2-x.cdr_gtco2
    check(x)
    return x

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--baseline',default='references/v67_fixed_early.csv');ap.add_argument('--out',default='inputs');args=ap.parse_args()
    b=pd.read_csv(args.baseline);check(b)
    assert abs(b.cdr_gtco2.sum()-TOTAL)<1e-6
    years=b.year.to_numpy()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    manifest=[]; ref=[]; leakrows=[]
    def write(df,name,group,phase,protocol='fixed',**kw):
        path=out/(name+'.csv');df.to_csv(path,index=False,float_format='%.16g')
        manifest.append(dict(case_id=name,group=group,phase=phase,protocol=protocol,
             file=path.name,off_stored_reversal_zero=(protocol=='leakage'),
             cumulative_cdr_gtco2=float(df.cdr_gtco2.sum()),**kw))
    def joos(t):return .2173+.2240*math.exp(-t/394.4)+.2824*math.exp(-t/36.54)+.2763*math.exp(-t/4.304)
    for total in [100.,250.,500.,1000.,TOTAL]:
        for rate in [2.,5.,10.,20.]:
            if math.ceil(total/rate-1e-10)>157:continue
            e=pulse(years,total,rate,False);l=pulse(years,total,rate,True)
            for phase,v in [('early',e),('late',l)]:
                write(scenario(b,v),f'size_{total:.2f}_rate_{rate:.0f}_{phase}','size_rate',phase,total_gtco2=total,rate_gtco2_per_year=rate)
            ref.append({'total_gtco2':total,'rate_gtco2_per_year':rate,'late_minus_early_ppm_joos':sum((l[i]-e[i])*joos(2183-int(y)) for i,y in enumerate(years))/7.8})
    assert len(ref)==14
    for frac in [0.,.10,.25,.5]:
        for tau in ([0] if frac==0. else [20,100]):
            for phase,late in [('early',False),('late',True)]:
                cdr=pulse(years,TOTAL,20.,late)
                stock=0.;leaks=[]
                for dose in cdr:
                    leakage=stock*(-math.expm1(-1./tau)) if tau else 0.
                    stock=stock-leakage+frac*dose
                    leaks.append(leakage)
                write(scenario(b,cdr,leaks),f'leak_{frac:.2f}_tau_{tau}_{phase}','leakage',phase,'leakage',leak_fraction=frac,leak_tau_years=tau,total_gtco2=TOTAL,rate_gtco2_per_year=20)
                leakrows.append(dict(leak_fraction=frac,leak_tau_years=tau,phase=phase,total_leaked_gtco2=sum(leaks),store_remaining_gtco2=stock))
                assert abs(sum(leaks)+stock-frac*TOTAL)<1e-7
    for phase in ['front','back']:
        rates=np.zeros(len(years))
        for i,y in enumerate(years):
            if y<2030:continue
            if phase=='front':
                if y<=2040:rates[i]=.91+(10-.91)*(y-2030)/10
                elif y<=2074:rates[i]=10.
            elif y<=2100:rates[i]=.16+(11.1-.16)*(y-2030)/70
        rates*=400./rates.sum()
        write(scenario(b,rates),f'year2100_{phase}','year2100',phase,total_gtco2=400,rate_gtco2_per_year=float(max(rates)))
    pd.DataFrame(manifest).to_csv(out/'manifest.csv',index=False)
    pd.DataFrame(ref).to_csv(out/'joos_reference.csv',index=False)
    pd.DataFrame(leakrows).to_csv(out/'leakage_mass_balance.csv',index=False)
    assert len(manifest)==44 and len(set(row['case_id'] for row in manifest))==44
    assert round(next(r for r in leakrows if r['leak_fraction']==.5 and r['leak_tau_years']==20 and r['phase']=='early')['total_leaked_gtco2'])==995
    print('PASS: 44 generated scenario inputs (28 size/rate, 14 leakage, 2 2100); NOT FaIR results')
    print('PASS: 14 analytical Joos comparisons and 14 leakage mass balances generated')
if __name__=='__main__': main()
