#!/usr/bin/env python3
"""Offline functional tests of the 56-case setup and fail-closed result audit.

Uses a clearly-labelled FAKE official-emissions fixture. No FaIR simulation is
performed; the fixture is NOT research data and is never shipped as output.
"""
from __future__ import annotations
import importlib.util,json,subprocess,sys,tempfile
from pathlib import Path
import numpy as np,pandas as pd
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from build_background import construct,ANCHORS,SCENARIOS,extract_total


def main():
 with tempfile.TemporaryDirectory() as tmp:
  t=Path(tmp);out=t/'inputs';out.mkdir()
  yrs=np.arange(2026,2184)
  # Build a fixture with exact official source anchor values but synthetic
  # intermediate years. This exercises only the CSV mapping/matrix plumbing.
  header=['scenario','region','variable','unit']+[f'{y}.5' for y in yrs]
  rows=[]
  for name,official in SCENARIOS.items():
   anchors=ANCHORS[name]
   values=np.interp(yrs,list(anchors),list(anchors.values()))
   for component in ['CO2 FFI','CO2 AFOLU']:
    data=values if component=='CO2 FFI' else np.zeros(len(yrs))
    rows.append([official,'World',component,'Gt CO2/yr',*data])
  source=t/'FAKE_TEST_FIXTURE_NOT_RESEARCH_DATA.csv'
  pd.DataFrame(rows,columns=header).to_csv(source,index=False,float_format='%.17g')
  # The sample-only fixture deliberately cannot pass the real pinned Git blob gate.
  try:construct(source,ROOT/'references/v67_fixed_early.csv',out)
  except (ValueError, RuntimeError) as e:assert 'Cannot read pinned Git object' in str(e) or 'Pinned source commit mismatch' in str(e) or 'Wrong pinned source file' in str(e)
  else:raise AssertionError('FAKE source was incorrectly accepted as pinned official data')
  # For test purposes only, bypass the blob gate and check mapping/shape.
  import shutil
  shutil.copy(ROOT/'inputs/manifest.csv',out/'manifest.csv')
  result=construct(source,ROOT/'references/v67_fixed_early.csv',out,strict_source=False)
  assert len(result)==56 and result.case_id.nunique()==56
  for item in result.loc[result.group=='background'].itertuples(index=False):
   d=pd.read_csv(out/item.file)
   assert len(d)==158 and np.isfinite(d.gross_co2_gtco2).all()
   assert item.background_scenario in SCENARIOS
  # Missing simulated outputs cannot be passed off as a successful matrix.
  for scope,cases in [('smoke',['size_100.00_rate_2_early','size_100.00_rate_2_late']),
                      ('full',result.case_id.tolist())]:
   expected=t/'expected_cases.json';expected.write_text(json.dumps({'scope':scope,'case_ids':cases}))
   reports=t/f'reports-{scope}'
   cmd=[sys.executable,str(ROOT/'src/compare_results.py'),
        '--expected-cases',str(expected),'--results',str(t/'absent_results'),
        '--references',str(ROOT/'references'),'--out',str(reports)]
   subprocess.run(cmd,check=False,capture_output=True)
   report=json.loads((reports/'status.json').read_text())
   assert report['status']=='INCOMPLETE_OR_NUMERIC_MISMATCH'
   assert len(report['missing_cases'])==len(cases)
  # Fail closed on plausible-looking but fabricated numeric output: shape and
  # metadata can pass while published values do not. NEVER use this fake data
  # as a scientific result. It remains only inside this temporary directory.
  fake_root=t/'fake_results'
  for name in ['size_100.00_rate_2_early','size_100.00_rate_2_late']:
   d=fake_root/name;d.mkdir(parents=True)
   val={'status':'PASS','configurations':841,'model_timebound':2184,
        'emissions_last_year':2183,'case_file':name+'.csv',
        'fair_source_commit':'ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79',
        'v62_runner_commit':'89a0f4ab18df25db3a05d4e39c6db06405456505',
        'forcing_tolerance':1e-4,'max_off_residual':0.,'max_on_residual':0.}
   (d/'validation.json').write_text(json.dumps(val))
   pd.DataFrame({'endpoint_year':[2100,2150,2183],
     'terminal_bound':[2101,2151,2184],
     'integrated_forcing_central_wm2yr':[0.,0.,0.],
     'terminal_delta_co2_central_ppm':[0.,0.,0.],
     'integrated_warming_central_cyr':[0.,0.,0.]}).to_csv(d/'fair_summary_endpoints.csv',index=False)
   pd.DataFrame({'year_bound':np.arange(2026,2185),
     'co2_on_p50_ppm':400.,'co2_off_p50_ppm':400.,
     'tas_on_p50_c':1.,'tas_off_p50_c':1.}).to_csv(d/'fair_median_timeseries.csv',index=False)
   for end in [2100,2150,2183]:
    pd.DataFrame({'member_id':[str(i) for i in range(841)],
      'terminal_bound':end+1,'terminal_delta_co2_ppm':0.,
      'integrated_co2_forcing_benefit_wm2_year':0.}).to_csv(d/f'fair_member_metrics_end_{end}.csv',index=False)
  expected=t/'expected_cases.json';expected.write_text(json.dumps({'scope':'smoke','case_ids':['size_100.00_rate_2_early','size_100.00_rate_2_late']}))
  reports=t/'fake_reports'
  subprocess.run([sys.executable,str(ROOT/'src/compare_results.py'),
    '--expected-cases',str(expected),'--results',str(fake_root),
    '--references',str(ROOT/'references'),'--out',str(reports)],check=False,capture_output=True)
  report=json.loads((reports/'status.json').read_text())
  assert report['valid_cases']==2 and report['comparisons_failed']>0 and report['status']=='INCOMPLETE_OR_NUMERIC_MISMATCH'
  print('PASS: pinned Git object verification, 12 background cases, 56-case completeness, and numeric-mismatch refusal')
if __name__=='__main__':main()
