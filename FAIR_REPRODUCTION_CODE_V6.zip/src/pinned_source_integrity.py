#!/usr/bin/env python3
"""Validate and read exact Git-index blobs at immutable source commits.

The Git blob SHA is a hash of bytes as stored in the Git object database.
Do NOT transform CRLF to LF *before* computing its SHA: some upstream CSVs
are committed with CRLF, and doing so causes an entirely false mismatch.
The worktree may legitimately use LF or CRLF depending on Git for Windows.
"""
from __future__ import annotations
import hashlib
import subprocess
from pathlib import Path


def git_output(directory: Path, *args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(directory), *args], stderr=subprocess.PIPE)


def read_pinned_blob(
    working_file: Path,
    *,
    repo_path: str,
    expected_blob: str,
    expected_commit: str,
) -> bytes:
    """Return *Git-committed* bytes; fail on wrong ref or non-newline worktree edits.

    repo_path is a POSIX-relative path such as examples/data/file.csv.
    The official data are read from HEAD:repo_path, never from a possibly
    newline-converted checkout. This works on Windows, Linux and macOS.
    """
    working_file = working_file.resolve()
    if repo_path.startswith('/') or '..' in Path(repo_path).parts or '\\' in repo_path:
        raise ValueError('Unsafe Git source path')
    try:
        root = Path(git_output(working_file.parent, 'rev-parse', '--show-toplevel').decode().strip()).resolve()
        rel = working_file.relative_to(root).as_posix()
        if rel != repo_path:
            raise ValueError(f'Wrong pinned source file location: {rel} instead of {repo_path}')
        commit = git_output(root, 'rev-parse', 'HEAD').decode().strip()
        if commit != expected_commit:
            raise ValueError(f'Pinned source commit mismatch: {commit} != {expected_commit}')
        object_ref = 'HEAD:' + repo_path
        blob = git_output(root, 'rev-parse', object_ref).decode().strip()
        if blob != expected_blob:
            raise ValueError(f'Pinned source Git blob mismatch: {blob} != {expected_blob}')
        git_bytes = git_output(root, 'show', object_ref)
        calculated = hashlib.sha1(
            b'blob ' + str(len(git_bytes)).encode('ascii') + b'\x00' + git_bytes
        ).hexdigest()
        if calculated != expected_blob:
            raise ValueError(f'Git object bytes do not match expected SHA: {calculated}')
        worktree_bytes = working_file.read_bytes()
        # Permit only Git's line ending checkout conversion. Content changes fail.
        if worktree_bytes.replace(b'\r\n', b'\n') != git_bytes.replace(b'\r\n', b'\n'):
            # Some Git-for-Windows clean/smudge rules can use more unusual
            # worktree end-of-line layouts. Accept such a checkout ONLY when
            # Git itself confirms there are no staged or unstaged changes.
            change = git_output(root, 'status', '--porcelain', '--untracked-files=no', '--', repo_path)
            if change.strip():
                raise ValueError('Worktree differs from pinned Git source beyond newline conversion')
        return git_bytes
    except subprocess.CalledProcessError as exc:
        raise RuntimeError(f'Cannot read pinned Git object at {working_file}: {exc}') from exc
