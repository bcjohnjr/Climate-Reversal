#!/usr/bin/env python3
"""Reproduce V4's CRLF false alarm and verify V5's exact Git object check.

Only creates small synthetic temporary Git repositories, never real research data.
"""
from __future__ import annotations
import hashlib
import subprocess
import sys
import tempfile
from pathlib import Path

from pinned_source_integrity import read_pinned_blob


def git(repo, *args):
    return subprocess.check_output(['git', '-C', str(repo), *args], stderr=subprocess.PIPE).decode().strip()


def expected_blob(content):
    return hashlib.sha1(b'blob '+str(len(content)).encode()+b'\x00'+content).hexdigest()


def main():
    with tempfile.TemporaryDirectory() as d:
        repo=Path(d)/'repo';repo.mkdir()
        git(repo,'init','-q')
        git(repo,'config','user.name','Test fixture')
        git(repo,'config','user.email','fixture@example.invalid')
        data=repo/'data';data.mkdir()
        path=data/'file.csv'
        # Upstream file is committed using CRLF, exactly the failure mode in V4.
        original=b'a,b\r\n1,2\r\n3,4\r\n'
        path.write_bytes(original)
        git(repo,'add','data/file.csv')
        git(repo,'commit','-qm','synthetic CRLF fixture')
        commit=git(repo,'rev-parse','HEAD')
        blob=git(repo,'rev-parse','HEAD:data/file.csv')
        assert blob==expected_blob(original)
        legacy=original.replace(b'\r\n',b'\n')
        assert expected_blob(legacy)!=blob, 'V4 broken line-ending check not reproduced'
        actual=read_pinned_blob(path,repo_path='data/file.csv',expected_blob=blob,expected_commit=commit)
        assert actual==original
        # Legitimate Git for Windows newline checkout conversion must also pass.
        path.write_bytes(legacy)
        assert read_pinned_blob(path,repo_path='data/file.csv',expected_blob=blob,expected_commit=commit)==original
        try:read_pinned_blob(path,repo_path='data/file.csv',expected_blob='0'*40,expected_commit=commit)
        except ValueError as e:assert 'blob mismatch' in str(e)
        else:raise AssertionError('Wrong expected source digest accepted')
        try:read_pinned_blob(path,repo_path='data/file.csv',expected_blob=blob,expected_commit='0'*40)
        except ValueError as e:assert 'commit mismatch' in str(e)
        else:raise AssertionError('Wrong commit accepted')
        path.write_bytes(b'a,b\r\n1,999\r\n3,4\r\n')
        try:read_pinned_blob(path,repo_path='data/file.csv',expected_blob=blob,expected_commit=commit)
        except ValueError as e:assert 'Worktree differs' in str(e)
        else:raise AssertionError('Modified contents accepted')
        print('PASS: committed CRLF blob, checkout LF variant, bad SHA/commit refusal, changed-data refusal')

if __name__=='__main__':main()
