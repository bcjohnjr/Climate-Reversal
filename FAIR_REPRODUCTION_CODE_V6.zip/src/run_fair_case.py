#!/usr/bin/env python3
"""Re-run one reconstructed carbon-removal sensitivity with PINNED original FaIR model.

No surrogate is used. The canonical V62.2 runner is imported after a surgical
END_YEAR 2300->2184 change; the original matched-forcing routine is invoked.
Save per-member results; do not equate 2183 start-of-year with end of 2183.
"""
from __future__ import annotations
import argparse, hashlib, importlib.util, json, os, sys
from pinned_source_integrity import read_pinned_blob
from pathlib import Path
import numpy as np
import pandas as pd

BASELINE_SHA256='f2d58812b8c54bfc52da1dee360ca06f8ccfb888791cf3dc1105bc038ae3a637'
ORIGINAL_END_YEAR='END_YEAR = 2300'
ORIGINAL_RUNNER_GIT_BLOB='4247d9e47a5ee9ae0c63c1da5e21dbfd9b064be5'

def load_module(original:Path,working:Path):
    # Verify the pinned Git blob *before* converting line endings for patching.
    # V4 incorrectly normalized the content before computing its Git SHA.
    canonical = read_pinned_blob(
        original, repo_path='run_fair_matched_forcing_v62.py',
        expected_blob=ORIGINAL_RUNNER_GIT_BLOB,
        expected_commit='89a0f4ab18df25db3a05d4e39c6db06405456505')
    canonical=canonical.replace(b'\r\n',b'\n')
    source=canonical.decode('utf-8')
    assert source.count(ORIGINAL_END_YEAR)==1,'Pinned runner changed; do not patch an unknown version'
    source=source.replace(ORIGINAL_END_YEAR,'END_YEAR = 2184',1)
    code=working/'run_fair_v62_pinned_end2184.py'
    code.write_text(source,encoding='utf-8')
    spec=importlib.util.spec_from_file_location('pinned_fair',code)
    m=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=m
    spec.loader.exec_module(m)
    assert m.END_YEAR==2184 and len(m.cfg)==841
    return m,code

def q(values):return [float(x) for x in np.quantile(values,[.05,.5,.95])]

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--case-file',required=True)
    p.add_argument('--reference',required=True,help='Recovered V67 fixed__early original trajectory')
    p.add_argument('--runner',required=True,help='Pinned V62.2 original run_fair_matched_forcing_v62.py')
    p.add_argument('--out',required=True)
    p.add_argument('--off-zero',action='store_true',help='Leakage sensitivity: removal OFF has no programme-created store')
    p.add_argument('--tolerance',type=float,default=1e-4)
    p.add_argument('--background',choices=['low','medium','high'],default=None,
       help='Use exact source-backed alternative gross-CO2 emissions')
    p.add_argument('--emissions',default=None,
       help='Official pinned FaIR extensions_1750-2500.csv; mandatory for --background')
    args=p.parse_args()
    out=Path(args.out).resolve();out.mkdir(parents=True,exist_ok=True)
    original=Path(args.runner).resolve();reference=Path(args.reference).resolve();case=Path(args.case_file).resolve()
    if not original.exists() or not reference.exists():raise FileNotFoundError('Pinned source or reference absent')
    df=pd.read_csv(case).sort_values('year').reset_index(drop=True)
    ref=pd.read_csv(reference).sort_values('year').reset_index(drop=True)
    cols=['year','gross_co2_gtco2','permafrost_co2_gtco2','stored_carbon_reversal_gtco2','cdr_gtco2','net_co2_gtco2']
    assert list(df.columns)==list(ref.columns)==cols
    assert np.array_equal(df.year.to_numpy(),np.arange(2026,2184))
    assert np.array_equal(ref.year.to_numpy(),df.year.to_numpy())
    assert float(np.max(np.abs((df.gross_co2_gtco2+df.permafrost_co2_gtco2+df.stored_carbon_reversal_gtco2-df.cdr_gtco2)-df.net_co2_gtco2)))<1e-8
    if args.background:
        if not args.emissions:raise ValueError('--emissions required for alternative background')
        from build_background import extract_total
        src=Path(args.emissions).resolve()
        expect_gross=extract_total(src,args.background,df.year.to_numpy(dtype=int))
        if float(np.max(np.abs(df.gross_co2_gtco2.to_numpy()-expect_gross)))>1e-8:
            raise ValueError('Background case is not identical to pinned official FaIR input')
    else:
        assert float(np.max(np.abs(df.gross_co2_gtco2-ref.gross_co2_gtco2)))<1e-10, 'Non-canonical background: use separately audited generator'
    assert float(np.max(np.abs(df.permafrost_co2_gtco2-ref.permafrost_co2_gtco2)))<1e-10
    if not args.off_zero:
        assert float(np.max(np.abs(df.stored_carbon_reversal_gtco2-ref.stored_carbon_reversal_gtco2)))<1e-10
    assert hashlib.sha256(reference.read_bytes()).hexdigest()=='30f415082222a9f0e23e9dc87a3605fcd5d856dcd0fb74dd4420d27821676666', 'Expected archived V67 reference SHA-256'
    os.chdir(out)
    # m imports ROOT='.' data at import time: case staged here.
    df.to_csv('external_validation_net_co2_trajectory.csv',index=False,float_format='%.17g')
    import fair
    if fair.__version__!='2.2.4':raise RuntimeError('FaIR 2.2.4 required, found '+str(fair.__version__))
    m,patched=load_module(original,out)
    assert m.CONV_GTCO2_PER_PPM>7.7 and m.CONV_GTCO2_PER_PPM<7.9
    if args.tolerance not in (1e-4,1e-7): raise ValueError('Only predeclared tolerances permitted')
    m.MATCH_TOL=args.tolerance
    # The published sensitivity comparisons all have one forcing target:
    # median OFF baseline of original canonical fixed-source trajectory.
    canonical_off={int(r.year):float(r.gross_co2_gtco2+r.permafrost_co2_gtco2+r.stored_carbon_reversal_gtco2)
                   for r in ref.itertuples(index=False)}
    # For bound 2184, 2184 emissions do not affect the evaluated state.
    canonical_off[2184]=canonical_off[2183]
    baseline,species,props=m.run_model(canonical_off)
    adj_species=m.choose_adjustment_species(species,props)
    years=np.asarray(baseline.timebounds,dtype=float)
    assert years[-1]==2184 and len(years)==2184-1750+1
    target=np.median(m.nonco2_forcing(baseline,species),axis=1)
    pd.DataFrame({'year':years.astype(int),'matched_nonco2_forcing_wm2':target}).query('year>=2026').to_csv('target_nonco2.csv',index=False)
    on,off,cdr=m.carbon_paths()
    if args.off_zero:
        for r in df.itertuples(index=False):
            off[int(r.year)]=float(r.gross_co2_gtco2+r.permafrost_co2_gtco2)
        off[2184]=off[2183]
    # Do not silently accept bad experiment case definitions.
    assert all(abs(on[int(r.year)]-r.net_co2_gtco2)<1e-9 for r in df.itertuples(index=False))
    assert all(abs(off[int(r.year)]-(r.gross_co2_gtco2+r.permafrost_co2_gtco2+(0. if args.off_zero else r.stored_carbon_reversal_gtco2)))<1e-9 for r in df.itertuples(index=False))
    print('Fitting OFF to common forcing target...',flush=True)
    foff,_,nonoff,_,auditoff=m.fit_matched_case(off,target,adj_species)
    print('Fitting ON to common forcing target...',flush=True)
    fon,_,nonon,_,auditon=m.fit_matched_case(on,target,adj_species)
    mask=years>2026
    offerr=float(np.max(np.abs(nonoff[mask,:]-target[mask,None])))
    onerr=float(np.max(np.abs(nonon[mask,:]-target[mask,None])))
    if max(offerr,onerr)>args.tolerance:raise RuntimeError('Forcing match failed')
    coon,cooff=np.asarray(m.co2(fon)),np.asarray(m.co2(foff))
    ton,toff=np.asarray(m.temp(fon)),np.asarray(m.temp(foff))
    n=len(m.ids)
    assert coon.shape==cooff.shape==ton.shape==toff.shape==(len(years),n)
    assert np.isfinite(coon).all() and np.isfinite(cooff).all() and (coon>0).all() and (cooff>0).all()
    assert float(np.max(np.abs(coon[years==2026,:]-cooff[years==2026,:])))<=1e-6
    assert float(np.max(np.abs(ton[years==2026,:]-toff[years==2026,:])))<=1e-6
    dc=cooff-coon;dfc=5.35*np.log(cooff/coon);dt=toff-ton
    ids=m.ids.astype(str)
    records=[]
    # np.trapz is available in the pinned NumPy 1.26.4.
    # np.trapezoid (NumPy >=2) must not be called in this package.
    for end_y in [2100,2150,2183]:
        bound=end_y+1
        ix=int(np.where(years==bound)[0][0])
        inte=(years>=2027)&(years<=bound)
        calc=lambda a: np.trapz(a[inte,:],years[inte],axis=0)
        member=pd.DataFrame({'member_id':ids,'terminal_bound':bound,'terminal_delta_co2_ppm':dc[ix,:],
          'integrated_delta_co2_ppm_year':calc(dc),'terminal_co2_forcing_benefit_wm2':dfc[ix,:],
          'integrated_co2_forcing_benefit_wm2_year':calc(dfc),
          'terminal_avoided_warming_c':dt[ix,:], 'integrated_avoided_warming_c_year':calc(dt)})
        assert member.shape[0]==841 and member.member_id.nunique()==841
        assert np.isfinite(member.drop(columns=['member_id']).to_numpy(float)).all()
        member.to_csv(f'fair_member_metrics_end_{end_y}.csv',index=False,float_format='%.16g')
        records.append(dict(endpoint_year=end_y,terminal_bound=bound,
            terminal_delta_co2_p50_ppm=q(dc[ix,:])[1],terminal_delta_co2_p05_ppm=q(dc[ix,:])[0],terminal_delta_co2_p95_ppm=q(dc[ix,:])[2],
            integrated_co2_forcing_benefit_median_member_wm2yr=q(calc(dfc))[1],
            integrated_avoided_warming_median_member_cyr=q(calc(dt))[1],
            # Manuscript central metric uses separately median of ON/OFF trajectories:
            terminal_delta_co2_central_ppm=float(np.median(cooff[ix,:])-np.median(coon[ix,:])),
            terminal_avoided_warming_central_c=float(np.median(toff[ix,:])-np.median(ton[ix,:])),
            co2_off_p50_ppm=float(np.median(cooff[ix,:])),
            integrated_forcing_central_wm2yr=float(np.trapz(5.35*np.log(np.median(cooff[inte,:],axis=1)/np.median(coon[inte,:],axis=1)),years[inte])),
            integrated_warming_central_cyr=float(np.trapz(np.median(toff[inte,:],axis=1)-np.median(ton[inte,:],axis=1),years[inte]))))
    ts=pd.DataFrame({'year_bound':years.astype(int),'co2_on_p50_ppm':np.median(coon,axis=1),
        'co2_off_p50_ppm':np.median(cooff,axis=1),'tas_on_p50_c':np.median(ton,axis=1),
        'tas_off_p50_c':np.median(toff,axis=1)})
    ts.query('year_bound>=2026').to_csv('fair_median_timeseries.csv',index=False,float_format='%.16g')
    pd.DataFrame(records).to_csv('fair_summary_endpoints.csv',index=False,float_format='%.16g')
    summary=dict(status='PASS',case_file=case.name,source_runner_sha256=hashlib.sha256(original.read_bytes()).hexdigest(),
       patched_runner_sha256=hashlib.sha256(patched.read_bytes()).hexdigest(),
       source_reference_sha256=hashlib.sha256(reference.read_bytes()).hexdigest(),
       fair_source='OMS-NetZero/FAIR',fair_source_commit='ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79',
       v62_runner_commit='89a0f4ab18df25db3a05d4e39c6db06405456505',
       configurations=n,model_timebound=2184,emissions_last_year=2183,forcing_tolerance=args.tolerance,
       max_off_residual=offerr,max_on_residual=onerr,off_stored_reversal_zero=args.off_zero,
       forcing_iterations=dict(off=auditoff,on=auditon),
       case_input_sha256=hashlib.sha256(case.read_bytes()).hexdigest(),
       staged_case_input_sha256=hashlib.sha256((out/'external_validation_net_co2_trajectory.csv').read_bytes()).hexdigest(),
       background_scenario=args.background or 'canonical',
       official_emissions_sha256=(hashlib.sha256(src.read_bytes()).hexdigest() if args.background else None),
       evaluation='End of emissions year y is FaIR timebound y+1. Trapezoids bounds 2027..y+1')
    Path('validation.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print('PASS',json.dumps({k:summary[k] for k in ('case_file','configurations','model_timebound','max_on_residual','max_off_residual')}),flush=True)
if __name__=='__main__':main()
