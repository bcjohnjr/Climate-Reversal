#!/usr/bin/env python3
"""Build FaIR background sensitivity *inputs* from the exact pinned FAIR emissions CSV.

Source: OMS-NetZero/FAIR at ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79
  examples/data/calibrated_constrained_ensemble/extensions_1750-2500.csv
The source file's Git blob SHA is 23858255b73562d49aa30f79192e92efd896736d.
NO emissions may be fabricated, extrapolated or inferred from quoted 2100 CO2 ppm.
"""
from __future__ import annotations
import argparse,hashlib,io,json
from pathlib import Path
import numpy as np,pandas as pd
from build_inputs import COLS,TOTAL,check,pulse,scenario
from pinned_source_integrity import read_pinned_blob

FAIR_COMMIT='ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79'
EM_REL='examples/data/calibrated_constrained_ensemble/extensions_1750-2500.csv'
EXPECTED_EM_GIT_BLOB_SHA='23858255b73562d49aa30f79192e92efd896736d'
# Official scenarios discovered by inspecting the exact Git blob, not by guessing.
SCENARIOS={'low':'low','medium':'medium-extension','high':'high-extension'}
# Sample source sums (CO2 AFOLU + CO2 FFI, Gt CO2/yr) check scenario/columns/units.
ANCHORS={
 'low':{2026:38.914210527,2100:-3.340241228,2183:-5.070285714},
 'medium':{2026:41.944576835,2100:40.195721657,2183:10.2},
 'high':{2026:44.079554968,2100:74.133647885,2183:67.0512},
}

def extract_total(path:Path, scenario:str, years:np.ndarray, frame=None):
    if frame is None:
        original = read_pinned_blob(
            path, repo_path=EM_REL, expected_blob=EXPECTED_EM_GIT_BLOB_SHA,
            expected_commit=FAIR_COMMIT)
        data = pd.read_csv(io.BytesIO(original))
    else:
        data = frame
    required={'scenario','region','variable','unit'}
    if not required.issubset(data.columns):raise ValueError('FAIR extensions input lacks required CSV columns')
    if scenario not in SCENARIOS:raise ValueError('Unexpected background: '+scenario)
    true_name=SCENARIOS[scenario]
    rows=data.loc[(data.scenario==true_name)&(data.region=='World')&
      (data.variable.isin(['CO2 FFI','CO2 AFOLU']))]
    if len(rows)!=2 or set(rows.variable)!={'CO2 FFI','CO2 AFOLU'}:
        raise ValueError('Missing/ambiguous source CO2 FFI and CO2 AFOLU rows for '+true_name)
    if set(rows.unit.astype(str))!={'Gt CO2/yr'}:raise ValueError('Unexpected FaIR emissions units; do not guess conversions')
    cols=[f'{int(y)}.5' for y in years]
    if not set(cols).issubset(data.columns):raise ValueError('Missing mid-year emissions columns')
    gross=rows.loc[:,cols].astype(float).sum(axis=0).to_numpy(dtype=float)
    if not np.isfinite(gross).all():raise ValueError('Nonfinite official pathway')
    for y,expected in ANCHORS[scenario].items():
        observed=gross[np.where(years==y)[0][0]]
        if abs(observed-expected)>2e-6:
            raise ValueError(f'Pinned data mismatch {scenario}/{y}: {observed} != {expected}')
    return gross

def construct(emissions:Path,baseline:Path,out:Path,strict_source:bool=True):
    base=pd.read_csv(baseline);check(base)
    yrs=base.year.to_numpy(dtype=int)
    if len(yrs)!=158:raise RuntimeError('Expected exactly 158 annual rows')
    out.mkdir(parents=True,exist_ok=True)
    # Git's raw object is the only source of truth. The official upstream CSV
    # is committed with CRLF; V4 incorrectly converted it to LF before hashing.
    # Do not silently overwrite the reference SHA or skip the integrity gate.
    if strict_source:
        payload = read_pinned_blob(
            emissions, repo_path=EM_REL, expected_blob=EXPECTED_EM_GIT_BLOB_SHA,
            expected_commit=FAIR_COMMIT)
    else:
        # Unit tests ONLY: synthetic fixture cannot become research output.
        payload = emissions.read_bytes()
    digest=hashlib.sha256(payload).hexdigest()
    git_blob=hashlib.sha1(b'blob '+str(len(payload)).encode('ascii')+b'\x00'+payload).hexdigest()
    data=pd.read_csv(io.BytesIO(payload))
    manifest=out/'manifest.csv'
    if not manifest.exists():raise FileNotFoundError('Run build_inputs.py to create core manifest first')
    initial=pd.read_csv(manifest).fillna('')
    if len(initial)!=44 or set(initial.group)!={'size_rate','leakage','year2100'}:
        raise ValueError('Build inputs afresh before appending the source-backed background matrix')
    items=[]; evidence={'official_emissions_path':EM_REL,'pinned_fair_commit':FAIR_COMMIT,
      'official_emissions_sha256':digest,'official_git_blob_sha':git_blob,'scenarios':{},'units':'Gt CO2/yr',
      'status':'INPUTS_RECOVERED_NOT_MODEL_RUNS'}
    for kind in SCENARIOS:
        gross=extract_total(emissions,kind,yrs,frame=data)
        evidence['scenarios'][kind]={'official_name':SCENARIOS[kind],
          'gross_co2_2026_gtco2yr':float(gross[0]),
          'gross_co2_2100_gtco2yr':float(gross[np.where(yrs==2100)[0][0]]),
          'gross_co2_2183_gtco2yr':float(gross[-1])}
        for total,rate in [(TOTAL,20.),(500.,10.)]:
            for phase in ['early','late']:
                cdr=pulse(yrs,total,rate,phase=='late')
                caseid=f'background_{kind}_size_{total:.2f}_rate_{rate:.0f}_{phase}'
                case=scenario(base,cdr,gross=gross)
                path=out/(caseid+'.csv');case.to_csv(path,index=False,float_format='%.16g')
                items.append({'case_id':caseid,'group':'background','phase':phase,
                   'protocol':'background','file':path.name,'off_stored_reversal_zero':False,
                   'cumulative_cdr_gtco2':float(cdr.sum()),'total_gtco2':total,
                   'rate_gtco2_per_year':rate,'background_scenario':kind,
                   'emissions_sha256':digest})
    final=pd.concat([initial,pd.DataFrame(items)],ignore_index=True)
    if len(final)!=56 or final.case_id.nunique()!=56:raise RuntimeError('Expected 56 unique cases')
    final.to_csv(manifest,index=False)
    (out/'background_source_audit.json').write_text(json.dumps(evidence,indent=2)+'\n',encoding='utf-8')
    print('PASS: 12 background source-backed input trajectories added; total 56 inputs (NOT 56 FaIR runs)')
    return final

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--emissions',required=True)
    ap.add_argument('--baseline',default='references/v67_fixed_early.csv');ap.add_argument('--out',default='inputs')
    a=ap.parse_args();construct(Path(a.emissions),Path(a.baseline),Path(a.out))
if __name__=='__main__':main()
