#!/usr/bin/env python3
"""Tests that can be performed WITHOUT claiming a FaIR climate-model run."""
from pathlib import Path
import hashlib,io,zipfile
import numpy as np,pandas as pd
from build_inputs import check,TOTAL
ROOT=Path(__file__).resolve().parents[1]

def main():
    sha=hashlib.sha256((ROOT/'references/v67_fixed_early.csv').read_bytes()).hexdigest()
    assert sha=='30f415082222a9f0e23e9dc87a3605fcd5d856dcd0fb74dd4420d27821676666'
    m=pd.read_csv(ROOT/'inputs/manifest.csv')
    assert len(m)==44 and m.case_id.nunique()==44
    assert m.group.value_counts().to_dict()=={'size_rate':28,'leakage':14,'year2100':2}
    for row in m.itertuples(index=False):
        f=ROOT/'inputs'/row.file;assert f.exists()
        d=pd.read_csv(f);check(d)
        assert abs(d.cdr_gtco2.sum()-row.cumulative_cdr_gtco2)<1e-7
    a=pd.read_csv(ROOT/'inputs/joos_reference.csv')
    tab=pd.read_csv(ROOT/'references/published_Table_S3.csv')
    assert len(a)==len(tab)==14
    for r in tab.itertuples(index=False):
        total=float(str(r[0]).replace(',',''));rate=float(r[1]);expected=float(r[4])
        sel=a[np.isclose(a.total_gtco2,total,atol=.01)&np.isclose(a.rate_gtco2_per_year,rate)]
        assert len(sel)==1 and abs(float(sel.iloc[0].late_minus_early_ppm_joos)-expected)<.006,(total,rate)
    leak=pd.read_csv(ROOT/'inputs/leakage_mass_balance.csv')
    ref=pd.read_csv(ROOT/'references/published_Table_S5.csv')
    for r in ref.itertuples(index=False):
        frac=float(r[0])/100; tau=0 if str(r[1]).strip() in ('—','-') else int(float(r[1]))
        z=leak[(np.isclose(leak.leak_fraction,frac))&(leak.leak_tau_years==tau)]
        assert len(z)==2
        for phase,target in [('early',int(r[5])),('late',int(r[6]))]:
            got=float(z.loc[z.phase==phase,'total_leaked_gtco2'].iloc[0]);assert round(got)==target,(frac,tau,phase,got,target)
    print('PASS: source digest, 44 input mass balances, 14 Joos Table S3 values, 14 Table S5 leakage balances')
if __name__=='__main__':main()
