#!/usr/bin/env python3
"""Independently audit original GitHub V67 artifacts without running FaIR."""
import io, json, zipfile
from pathlib import Path
import numpy as np
import pandas as pd

def read_member(path):
    with zipfile.ZipFile(path) as z:
        m=pd.read_csv(io.BytesIO(z.read('fair_work/fair_member_metrics.csv')))
        x=pd.read_csv(io.BytesIO(z.read('trajectories/fixed__'+path.stem.split('-')[-1]+'.csv')))
    assert len(m)==841 and m.member_id.nunique()==841
    assert set(x.year)==set(range(2026,2184))
    assert np.isfinite(m.drop(columns=['member_id']).to_numpy(float)).all()
    return m.set_index('member_id').sort_index()

def main():
    root=Path(__file__).resolve().parents[1]
    e=read_member(root/'archived/V67-fixed-early.zip')
    l=read_member(root/'archived/V67-fixed-late.zip')
    assert e.index.equals(l.index)
    early_forcing=e.integrated_co2_forcing_benefit_wm2_year-l.integrated_co2_forcing_benefit_wm2_year
    late_terminal=l.terminal_delta_co2_ppm-e.terminal_delta_co2_ppm
    both=(early_forcing>0)&(late_terminal>0)
    result={'source':'Original V67 GitHub Actions artifact, fixed source, annual bound 2183 (NOT corrected 2184)',
      'members':len(e),'joint_members':int(both.sum()),'joint_percentage':float(both.mean()*100),
      'min_early_integrated_forcing_margin_wm2yr':float(early_forcing.min()),
      'min_late_terminal_concentration_margin_ppm':float(late_terminal.min()),
      'published_SI_Table_S1_corrected_2184_minima':{'early_forcing':60.75,'late_terminal':17.63},
      'warning':'Do not compare archived 2183 minima as if they were 2184; no re-run is claimed.'}
    out=root/'archived'/ 'v67_audit_verified.json';out.write_text(json.dumps(result,indent=2))
    assert result['joint_members']==841 and 60<result['min_early_integrated_forcing_margin_wm2yr']<62
    assert 16<result['min_late_terminal_concentration_margin_ppm']<18
    print('PASS original V67 841-member checks; output at',out)
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()
