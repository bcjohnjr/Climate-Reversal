#!/usr/bin/env python3
"""Regression test: S4 CO2-at-2100 is FaIR timebound 2100, not 2101."""
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--results',default='results');a=p.parse_args(); root=Path(a.results)
target={'low':443.0,'medium':595.0,'high':722.0}
for bg,pub in target.items():
 f=root/f'background_{bg}_size_500.00_rate_10_early/fair_median_timeseries.csv'
 ts=pd.read_csv(f)
 at2100=ts.loc[ts.year_bound==2100,'co2_off_p50_ppm'];at2101=ts.loc[ts.year_bound==2101,'co2_off_p50_ppm']
 assert len(at2100)==len(at2101)==1
 assert abs(float(at2100.iloc[0])-pub)<.51,(bg,at2100,pub)
 assert abs(float(at2101.iloc[0])-pub)>.51,(bg,'regression unexpectedly not sensitive')
 print(f'PASS {bg}: timebound 2100={at2100.iloc[0]:.6f}; timebound 2101={at2101.iloc[0]:.6f}; Table S4={pub:.0f}')
