#!/usr/bin/env python3
"""Build a portable results-only ZIP for an independent FaIR manuscript audit.

Does not run, modify, or validate climate simulations. Explicitly preserves
verification metadata so passing a launcher does not imply a scientific PASS.
"""
from __future__ import annotations
import hashlib
import json
import zipfile
from datetime import datetime
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT / ('FaIR_V5_RUN_OUTPUTS_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.zip')
FOLDERS=('results','reports','archived','logs')
EXTRA=('REPRODUCTION_STATUS.json','VERIFICATION_REPORT.md','README_FIRST.md')

def main():
    files=[]
    for folder in FOLDERS:
        directory=ROOT/folder
        if directory.is_dir():
            files.extend(p for p in directory.rglob('*') if p.is_file())
    files.extend(ROOT/f for f in EXTRA if (ROOT/f).is_file())
    files=sorted(set(files))
    if not files:
        raise SystemExit('No results or reports found. Run RUN_WINDOWS.bat first.')
    manifest=[]
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for f in files:
            rel=f.relative_to(ROOT).as_posix()
            z.write(f,rel)
            payload=f.read_bytes()
            manifest.append(dict(path=rel,size=len(payload),sha256=hashlib.sha256(payload).hexdigest()))
        z.writestr('FILE_SHA256_MANIFEST.json',json.dumps(manifest,indent=2))
        z.writestr('COLLECTOR_NOTICE.txt','Files are copied as-is. The collector does not run FaIR or certify model results.\n')
    with zipfile.ZipFile(OUT) as z:
        assert z.testzip() is None
    statuses=list((ROOT/'results').glob('*/validation.json')) if (ROOT/'results').exists() else []
    print('Created:',OUT)
    print('Files:',len(files),'Results with validation.json:',len(statuses))
    if not statuses: print('WARNING: No new FaIR model results found. Package may contain only archived checks and logs.')
    print('Upload the ZIP to ChatGPT for independent processing.')

if __name__=='__main__':main()
