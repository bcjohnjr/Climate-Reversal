# FaIR carbon-removal sensitivity reproduction — V6

This archive supplies the source and input files for the 56-case FaIR 2.2.4 experiment. It does **not** contain the FaIR third-party source/calibration files; the runner retrieves the original pinned upstream Git commits and checks them before use.

## Source provenance

- FaIR 2.2.4 source: `OMS-NetZero/FAIR` at `ec46fefc8f8c6b560a8b78ab1f4a9a5e04537f79`.
- FaIR calibration: `fair-calibrate 1.4.1`, **841** constrained configurations, available in the pinned FaIR repository.
- Original FaIR matched-forcing source: `bcjohnjr/Planetary-Restoration-Version-62.2` at `89a0f4ab18df25db3a05d4e39c6db06405456505`.
- Reference 2026–2183 trajectory: archived V67 `fixed__early` recovered from original GitHub Actions artifacts.
- Python 3.12, FaIR 2.2.4, NumPy 1.26.4, pandas 2.2.3, scipy 1.14.1, xarray 2024.10.0.
- Each case matches future non-CO2 forcing to the same canonical target, allowing the CO2-removal timing sensitivity to be tested. Run validation tolerances are recorded in each case JSON.

## Reproduce from scratch

On Windows, in this extracted source archive, run `RUN_WINDOWS.bat` to verify the 2-case smoke test, then `RUN_FULL_WINDOWS.bat` to run all 56. A 64-bit CPython 3.12 and Git must be installed, and an internet connection is required for source checkout and package installation. The runner verifies pinned Git objects; it does not install a numerical surrogate.

Alternatively run `python src/execute.py --scope full --compare` from the package root after installing the exact versions in `requirements.txt`, with `git` on PATH.

The script regenerates inputs including 12 official background scenarios, runs each case, and performs the strict published comparison. Case outputs appear under `results/<case_id>/` and aggregate comparisons under `reports/`.

## Verify the archived 56 cases without rerunning FaIR

From the **outer flat repository upload**, run `python FAIR_VERIFY.py --verify` with Python, NumPy and pandas installed; it unpacks the source/data ZIPs into an independent temporary workspace and runs the scientific comparator. The expected audit is 56 valid cases and 152 of 152 published comparisons passing.

## Timebound convention (important)

The 2183 end-of-year endpoint is FaIR **timebound 2184**. The published Table S4 column "OFF CO2 in 2100" instead corresponds to FaIR **timebound 2100**, which is **not** the summary CSV's endpoint-year-2100 row (that row corresponds to timebound 2101). V6 corrects the comparator and includes `src/test_s4_timebound_regression.py`.

## What is and is not established

The complete matrix was executed on the author's Windows system. All archived cases have 841 unique member summaries at each of three endpoints, 159 annual median values for timebounds 2026–2184, complete validation reports and matched forcing residuals below 1e-4 W/m2. The independent comparator agrees with the numerical supplementary Tables S3–S6 within the predeclared rounding tolerances. **This is numerical reproducibility of these experiments, not independent validation of the scientific assumptions, original figure-generation source, Hector/OSCAR re-runs, climate realism, or journal acceptance.**

The originally recorded `case_input_sha256` in each archived validation.json refers to the pre-staging CSV; the script writes an equivalent CSV with different numeric formatting inside the output folder. The archived staged CSV therefore does not have the same byte hash. The discrepancy is disclosed; V6 adds `staged_case_input_sha256` to future runs and retains both hashes. The outer package's `FAIR_RESULTS_SHA256.csv` provides exact hashes of the preserved original output bytes.
