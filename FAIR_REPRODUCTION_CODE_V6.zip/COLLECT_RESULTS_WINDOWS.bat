@echo off
setlocal EnableExtensions
cd /d "%~dp0"
if exist ".venv_py312\Scripts\python.exe" (
  ".venv_py312\Scripts\python.exe" src\collect_results.py
) else (
  py -3.12 src\collect_results.py
)
if errorlevel 1 echo ERROR: Result collection failed.
echo.
pause
