@echo off
setlocal EnableExtensions
cd /d "%~dp0"

set "SCOPE=%~1"
if "%SCOPE%"=="" set "SCOPE=smoke"
if /I "%SCOPE%"=="preflight" goto :scope_ok
if /I "%SCOPE%"=="smoke" goto :scope_ok
if /I "%SCOPE%"=="core" goto :scope_ok
if /I "%SCOPE%"=="background" goto :scope_ok
if /I "%SCOPE%"=="full" goto :scope_ok
echo ERROR: Unsupported scope "%SCOPE%".
echo Allowed choices: preflight, smoke, core, background, full
pause
exit /b 1

:scope_ok
echo ================================================================
echo Climate Reversal FaIR reproduction V5 - Windows launcher
echo ================================================================
echo Scope: %SCOPE%
echo A 64-bit Python 3.12 environment is REQUIRED.
echo This script NEVER builds NumPy from source.
echo.

set "PYRUN="
where py >nul 2>&1
if not errorlevel 1 (
  py -3.12 -c "import sys,struct; assert sys.version_info[:2] == (3,12) and struct.calcsize('P') == 8" >nul 2>&1
  if not errorlevel 1 set "PYRUN=py -3.12"
)
if defined PYRUN goto :python_ok
where python >nul 2>&1
if not errorlevel 1 (
  python -c "import sys,struct; assert sys.version_info[:2] == (3,12) and struct.calcsize('P') == 8" >nul 2>&1
  if not errorlevel 1 set "PYRUN=python"
)
if not defined PYRUN goto :python_missing

:python_ok
%PYRUN% -c "import sys,platform;print('Selected interpreter:',sys.executable);print('Python:',sys.version.split()[0],platform.architecture()[0])"
where git >nul 2>&1
if errorlevel 1 goto :git_missing

rem Isolate from V2/V3 virtual environments, which may use a newer Python.
set "VENV=.venv_py312"
if not exist "%VENV%\Scripts\python.exe" (
  echo Creating the isolated Python 3.12 environment...
  %PYRUN% -m venv "%VENV%"
  if errorlevel 1 goto :venv_error
)
"%VENV%\Scripts\python.exe" -c "import sys,struct; assert sys.version_info[:2] == (3,12) and struct.calcsize('P') == 8"
if errorlevel 1 goto :venv_wrong

echo Installing prebuilt Windows wheels only...
"%VENV%\Scripts\python.exe" -m pip --version
"%VENV%\Scripts\python.exe" -m pip install --disable-pip-version-check --only-binary=:all: -r requirements.txt
if errorlevel 1 goto :pip_error
"%VENV%\Scripts\python.exe" -m pip check
if errorlevel 1 goto :pip_error
"%VENV%\Scripts\python.exe" -c "import sys,numpy,pandas,scipy,xarray,fair;assert sys.version_info[:2] == (3,12);assert numpy.__version__ == '1.26.4';assert fair.__version__ == '2.2.4';print('RUNTIME VERIFIED: Python',sys.version.split()[0],'NumPy',numpy.__version__,'FaIR',fair.__version__)"
if errorlevel 1 goto :pip_error

echo.
echo Launching %SCOPE% validation...
"%VENV%\Scripts\python.exe" src\execute.py --scope "%SCOPE%"
if errorlevel 1 goto :run_error

echo.
echo Launcher finished. Check reports\status.json for SCIENTIFIC verification.
echo To collect results for independent checking, run COLLECT_RESULTS_WINDOWS.bat.
echo A passing installation is not the same as a reproduced manuscript.
pause
exit /b 0

:python_missing
echo.
echo ERROR: 64-bit Python 3.12 was not detected.
echo NumPy 1.26.4 is not supported by Python 3.13 or later.
echo Double-click INSTALL_PYTHON_312_WINDOWS.bat to install Python 3.12,
echo then open a NEW terminal and run RUN_WINDOWS.bat again.
echo Or install Python 3.12 x64 from https://www.python.org/downloads/
echo You do NOT need Microsoft C++ Build Tools.
echo.
echo Detected Python versions, if the launcher is available:
where py >nul 2>&1
if not errorlevel 1 py -0p
where python >nul 2>&1
if not errorlevel 1 python --version
pause
exit /b 1

:git_missing
echo.
echo ERROR: Git for Windows is missing from PATH.
echo Install from https://git-scm.com/downloads/win
pause
exit /b 1

:venv_error
echo.
echo ERROR: Failed to create the Python 3.12 virtual environment.
pause
exit /b 1

:venv_wrong
echo.
echo ERROR: An incompatible virtual environment exists at %VENV%.
echo Delete ONLY %VENV% in this V5 folder, then run again.
echo Your archived results, sources and references are not affected.
pause
exit /b 1

:pip_error
echo.
echo ERROR: Binary package install or import check failed.
echo No source compilation was attempted.
echo Confirm Windows x64 and Python 3.12; then review the error above.
echo Run DIAGNOSE_WINDOWS.bat for interpreter information.
pause
exit /b 1

:run_error
echo.
echo FaIR science run or validation FAILED. This is distinct from installation.
echo Review the output above and reports\status.json if written.
echo DO NOT claim results reproduced unless the numerical audit passes.
pause
exit /b 1
