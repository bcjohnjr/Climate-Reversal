# Numerical Tables S1–S6 (published values)

These CSVs were extracted from table cells in the author's attached `GBC_Supporting_Information.docx`, without changing values or inferring raw simulation records. The values are manuscript-reported aggregate statistics and may include formatted numerical strings. They are *not* the underlying 841-member raw data for Figures 3 or 4; they are suitable as a reference for subsequent independent numerical comparison.
