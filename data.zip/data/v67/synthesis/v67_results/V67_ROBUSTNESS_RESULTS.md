# V67 permanence, counterfactual and permafrost robustness results

- Ranking reversal across stored-carbon protocols/models: **True**
- Early avoided-warming advantage across FaIR/Hector: **True**
- Ranking reversal across permafrost sensitivity: **True**

## Central early-vs-late results

| Reversal protocol | Model | Early minus late integrated forcing (W m^-2 yr) | Late minus early terminal CO2 (ppm) |
|---|---|---:|---:|
| fixed_source | FaIR | 79.0487 | 19.4533 |
| fixed_source | Hector | 61.9672 | 29.8966 |
| fixed_source | OSCAR | 84.6796 | 23.6925 |
| ideal_permanent | FaIR | 79.0988 | 19.4280 |
| ideal_permanent | Hector | 61.9504 | 29.7185 |
| ideal_permanent | OSCAR | 83.8275 | 22.1386 |
| coupled_program | FaIR | 75.7389 | 18.6141 |
| coupled_program | Hector | 59.3605 | 28.6337 |
| coupled_program | OSCAR | 79.3944 | 23.1279 |

## Ensemble-member support

| Protocol | Model | Members | Early wins integrated forcing | Late wins terminal CO2 | Joint reversal |
|---|---|---:|---:|---:|---:|
| fixed_source | FaIR | 841 | 1.000 | 1.000 | 1.000 |
| fixed_source | OSCAR | 200 | 1.000 | 0.825 | 0.825 |
| ideal_permanent | FaIR | 841 | 1.000 | 1.000 | 1.000 |
| ideal_permanent | OSCAR | 200 | 1.000 | 0.825 | 0.825 |
| coupled_program | FaIR | 841 | 1.000 | 1.000 | 1.000 |
| coupled_program | OSCAR | 200 | 1.000 | 0.800 | 0.800 |

Coupled reversal is a diagnostic robustness sensitivity, not a mechanistic storage-failure model. Permafrost zero/double is exogenous amplitude sensitivity, not fully endogenous permafrost physics.
